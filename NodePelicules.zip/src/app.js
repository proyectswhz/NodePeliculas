import "dotenv/config";
import express from "express";
import cors from "cors";
import { connectDB } from "./config/database.js";
// Importamos los endpoints de movieRoutes
import moviesRoutes from "./routes/movieRoutes.js";

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors({ origin: "http://localhost:3000" }));
app.use(express.json());

// Conectar y organizar las rutas
app.use("/api/movies", moviesRoutes);

// Arranque del servidor
const iniciarServidor = async () => {
  try {
    // Conectamos a la base de datos
    await connectDB();

    //Una vez conectados, iniciamos el servidor
    app.listen(PORT, (req, res) => {
      console.log(`✅ Servidor corriendo en el puerto ${PORT}`);
      console.log(`👉 http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error("Error al iniciar el servidor: ", error);
    process.exit(1);
  }
};
// Iniciamos el servidor
iniciarServidor();
