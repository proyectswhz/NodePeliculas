# Peliculas API

---

## Requisitos previos

- Node.js - (https://nodejs.org) - Versión 24
- pnpm (`npm install -g pnpm`)
- MongoDB - (https://www.mongodb.com/)

---

## 📦 Instalación

1. Clona el repositorio o descarga el proyecto:

```bash
git clone <url-repositorio>
cd <nombre-carpeta>
```

2. Instalar las dependencias.

```bash
pnpm install
```

---

## ⚙️ Configuración

1. Crear archivo .env
2. Añadir las siguientes variables de entorno con tus datos:

```text
PORT=3000
MONGO_URI=mongodb://localhost:27017/tu-nombre-de-base-de-datos
```

---

## 🚀 Ejecución del proyecto

- Modo desarrollo, con recarga automática.

```bash
pnpm dev
```

- Modo producción:

```bash
pnpm start
```
